// Main Dashboard Application
class MaintAIDashboard {
    constructor() {
        this.currentLanguage = 'en';
        this.currentTab = 'overview';
        this.refreshInterval = null;
        this.charts = {};
        this.data = {
            summary: null,
            sensors: [],
            alerts: [],
            machines: [],
            analytics: null
        };
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupTabNavigation();
        this.loadInitialData();
        this.startAutoRefresh();
        this.updateConnectionStatus(true);
    }

    setupEventListeners() {
        // Language selector
        document.getElementById('language-selector').addEventListener('change', (e) => {
            this.changeLanguage(e.target.value);
        });

        // Tab navigation
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const tab = e.currentTarget.dataset.tab;
                this.switchTab(tab);
            });
        });

        // Refresh buttons
        document.getElementById('refresh-alerts')?.addEventListener('click', () => {
            this.loadAlerts();
        });

        // Alert severity filter
        document.getElementById('alert-severity-filter')?.addEventListener('change', (e) => {
            this.filterAlerts(e.target.value);
        });
    }

    setupTabNavigation() {
        const style = document.createElement('style');
        style.textContent = `
            .tab-button {
                padding: 0.75rem 1rem;
                border-bottom: 2px solid transparent;
                color: #6b7280;
                font-medium: 500;
                transition: all 0.2s;
                cursor: pointer;
                background: none;
                border-top: none;
                border-left: none;
                border-right: none;
            }
            
            .tab-button:hover {
                color: #374151;
                border-bottom-color: #d1d5db;
            }
            
            .tab-button.active {
                color: #3b82f6;
                border-bottom-color: #3b82f6;
            }
            
            .tab-content {
                display: none;
            }
            
            .tab-content.active {
                display: block;
            }
        `;
        document.head.appendChild(style);
    }

    switchTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-button').forEach(button => {
            button.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
            content.classList.add('hidden');
        });
        
        const targetTab = document.getElementById(`${tabName}-tab`);
        if (targetTab) {
            targetTab.classList.remove('hidden');
            targetTab.classList.add('active');
        }

        this.currentTab = tabName;

        // Load tab-specific data
        switch (tabName) {
            case 'overview':
                this.loadOverviewData();
                break;
            case 'sensors':
                this.loadSensorData();
                break;
            case 'alerts':
                this.loadAlerts();
                break;
            case 'machines':
                this.loadMachines();
                break;
            case 'analytics':
                this.loadAnalytics();
                break;
        }
    }

    changeLanguage(language) {
        this.currentLanguage = language;
        
        // Update document direction for Arabic
        document.body.dir = language === 'ar' ? 'rtl' : 'ltr';
        document.body.className = language === 'ar' ? 'bg-gray-50 arabic' : 'bg-gray-50 english';
        
        // Update all translatable elements
        this.updateTranslations();
        
        // Refresh data to get translated content
        this.loadCurrentTabData();
    }

    updateTranslations() {
        document.querySelectorAll('[data-translate]').forEach(element => {
            const key = element.dataset.translate;
            const translation = translations[this.currentLanguage]?.[key];
            if (translation) {
                element.textContent = translation;
            }
        });
    }

    async loadInitialData() {
        this.showLoading(true);
        
        try {
            await Promise.all([
                this.loadOverviewData(),
                this.loadSensorData()
            ]);
        } catch (error) {
            console.error('Error loading initial data:', error);
            this.showError('Failed to load dashboard data');
        } finally {
            this.showLoading(false);
        }
    }

    async loadOverviewData() {
        try {
            const summary = await apiClient.getDashboardSummary();
            this.data.summary = summary;
            this.updateOverviewCards(summary);
            this.loadRecentAlerts();
            this.updateSystemHealthChart();
        } catch (error) {
            console.error('Error loading overview data:', error);
        }
    }

    async loadSensorData() {
        try {
            const sensors = await apiClient.getLatestSensorData();
            this.data.sensors = sensors;
            this.updateSensorReadings(sensors);
            this.updateSensorTrendsChart();
        } catch (error) {
            console.error('Error loading sensor data:', error);
        }
    }

    async loadAlerts() {
        try {
            const alerts = await apiClient.getAlerts();
            this.data.alerts = alerts;
            this.updateAlertsTable(alerts);
        } catch (error) {
            console.error('Error loading alerts:', error);
        }
    }

    async loadMachines() {
        try {
            const machines = await apiClient.getMachines();
            this.data.machines = machines;
            this.updateMachinesGrid(machines);
        } catch (error) {
            console.error('Error loading machines:', error);
        }
    }

    async loadAnalytics() {
        try {
            const analytics = await apiClient.getAnalytics();
            this.data.analytics = analytics;
            this.updateFailurePredictionsChart();
            this.updatePerformanceMetrics();
        } catch (error) {
            console.error('Error loading analytics:', error);
        }
    }

    loadCurrentTabData() {
        switch (this.currentTab) {
            case 'overview':
                this.loadOverviewData();
                break;
            case 'sensors':
                this.loadSensorData();
                break;
            case 'alerts':
                this.loadAlerts();
                break;
            case 'machines':
                this.loadMachines();
                break;
            case 'analytics':
                this.loadAnalytics();
                break;
        }
    }

    updateOverviewCards(summary) {
        document.getElementById('total-devices').textContent = summary.total_devices || 0;
        document.getElementById('active-devices').textContent = summary.active_devices || 0;
        document.getElementById('active-alerts').textContent = summary.active_alerts || 0;
        document.getElementById('critical-alerts').textContent = summary.critical_alerts || 0;
    }

    async loadRecentAlerts() {
        try {
            const alerts = await apiClient.getAlerts({ limit: 5, resolved: false });
            this.updateRecentAlertsList(alerts);
        } catch (error) {
            console.error('Error loading recent alerts:', error);
        }
    }

    updateRecentAlertsList(alerts) {
        const container = document.getElementById('recent-alerts-list');
        
        if (!alerts || alerts.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-check-circle text-4xl mb-4 text-green-500"></i>
                    <p data-translate="no_active_alerts">No active alerts</p>
                </div>
            `;
            return;
        }

        container.innerHTML = alerts.map(alert => `
            <div class="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div class="flex items-center space-x-4">
                    <div class="flex-shrink-0">
                        <i class="fas fa-exclamation-triangle text-${this.getSeverityColor(alert.severity)}-500"></i>
                    </div>
                    <div>
                        <p class="font-medium text-gray-900">${alert.device_id} - ${alert.sensor_type}</p>
                        <p class="text-sm text-gray-600">${alert.message}</p>
                        <p class="text-xs text-gray-400">
                            <i class="fas fa-clock mr-1"></i>
                            ${this.formatTimestamp(alert.timestamp)}
                        </p>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="px-2 py-1 text-xs font-medium rounded-full severity-${alert.severity}">
                        ${alert.severity}
                    </span>
                    <button onclick="dashboard.acknowledgeAlert(${alert.id})" 
                            class="px-3 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700">
                        <span data-translate="acknowledge">Acknowledge</span>
                    </button>
                </div>
            </div>
        `).join('');
        
        this.updateTranslations();
    }

    updateSensorReadings(sensors) {
        const container = document.getElementById('sensor-readings-list');
        
        if (!sensors || sensors.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-thermometer-half text-4xl mb-4"></i>
                    <p data-translate="no_sensor_data">No sensor data available</p>
                </div>
            `;
            return;
        }

        container.innerHTML = sensors.map(sensor => `
            <div class="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div class="flex items-center space-x-4">
                    <div class="flex-shrink-0">
                        <i class="fas fa-${this.getSensorIcon(sensor.sensor_type)} text-blue-500"></i>
                    </div>
                    <div>
                        <p class="font-medium text-gray-900">${sensor.device_id}</p>
                        <p class="text-sm text-gray-600 capitalize">${sensor.sensor_type}</p>
                        <p class="text-xs text-gray-400">
                            <i class="fas fa-map-marker-alt mr-1"></i>
                            ${sensor.location || 'Unknown location'}
                        </p>
                    </div>
                </div>
                <div class="text-right">
                    <p class="text-2xl font-bold text-gray-900">${sensor.value}</p>
                    <p class="text-sm text-gray-600">${sensor.unit}</p>
                    <p class="text-xs text-gray-400">${this.formatTimestamp(sensor.timestamp)}</p>
                </div>
            </div>
        `).join('');
    }

    updateAlertsTable(alerts) {
        const container = document.getElementById('alerts-table');
        
        if (!alerts || alerts.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-check-circle text-4xl mb-4 text-green-500"></i>
                    <p data-translate="no_alerts">No alerts found</p>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            <span data-translate="device">Device</span>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            <span data-translate="sensor">Sensor</span>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            <span data-translate="severity">Severity</span>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            <span data-translate="message">Message</span>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            <span data-translate="timestamp">Timestamp</span>
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            <span data-translate="actions">Actions</span>
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    ${alerts.map(alert => `
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                ${alert.device_id}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">
                                ${alert.sensor_type}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-medium rounded-full severity-${alert.severity}">
                                    ${alert.severity}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900 max-w-xs truncate">
                                ${alert.message}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                ${this.formatTimestamp(alert.timestamp)}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                                ${!alert.acknowledged ? `
                                    <button onclick="dashboard.acknowledgeAlert(${alert.id})" 
                                            class="text-blue-600 hover:text-blue-900">
                                        <span data-translate="acknowledge">Acknowledge</span>
                                    </button>
                                ` : ''}
                                ${!alert.resolved ? `
                                    <button onclick="dashboard.resolveAlert(${alert.id})" 
                                            class="text-green-600 hover:text-green-900">
                                        <span data-translate="resolve">Resolve</span>
                                    </button>
                                ` : ''}
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        
        this.updateTranslations();
    }

    updateMachinesGrid(machines) {
        const container = document.getElementById('machines-grid');
        
        if (!machines || machines.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-8 text-gray-500">
                    <i class="fas fa-industry text-4xl mb-4"></i>
                    <p data-translate="no_machines">No machines found</p>
                </div>
            `;
            return;
        }

        container.innerHTML = machines.map(machine => `
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-medium text-gray-900">${machine.name}</h3>
                    <span class="px-2 py-1 text-xs font-medium rounded-full ${this.getStatusClass(machine.status)}">
                        ${machine.status}
                    </span>
                </div>
                
                <div class="space-y-3">
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600" data-translate="machine_type">Type:</span>
                        <span class="font-medium">${machine.machine_type}</span>
                    </div>
                    
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600" data-translate="location">Location:</span>
                        <span class="font-medium">${machine.location || 'Unknown'}</span>
                    </div>
                    
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600" data-translate="active_alerts">Active Alerts:</span>
                        <span class="font-medium text-red-600">${machine.active_alerts || 0}</span>
                    </div>
                    
                    ${machine.latest_sensors ? `
                        <div class="mt-4 pt-4 border-t border-gray-200">
                            <h4 class="text-sm font-medium text-gray-900 mb-2" data-translate="latest_readings">Latest Readings:</h4>
                            <div class="grid grid-cols-2 gap-2 text-xs">
                                ${Object.entries(machine.latest_sensors).map(([type, data]) => `
                                    <div class="flex justify-between">
                                        <span class="text-gray-600 capitalize">${type}:</span>
                                        <span class="font-medium">${data.value} ${data.unit}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `).join('');
        
        this.updateTranslations();
    }

    updateSystemHealthChart() {
        const ctx = document.getElementById('system-health-chart');
        if (!ctx) return;

        // Destroy existing chart if it exists
        if (this.charts.systemHealth) {
            this.charts.systemHealth.destroy();
        }

        // Sample data - in real implementation, this would come from API
        const data = {
            labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'],
            datasets: [{
                label: 'System Health Score',
                data: [95, 92, 88, 90, 94, 96],
                borderColor: 'rgb(59, 130, 246)',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                tension: 0.4
            }]
        };

        this.charts.systemHealth = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    updateSensorTrendsChart() {
        const ctx = document.getElementById('sensor-trends-chart');
        if (!ctx) return;

        // Destroy existing chart if it exists
        if (this.charts.sensorTrends) {
            this.charts.sensorTrends.destroy();
        }

        // Sample data - in real implementation, this would come from API
        const data = {
            labels: ['1h ago', '45m ago', '30m ago', '15m ago', 'Now'],
            datasets: [
                {
                    label: 'Temperature (°C)',
                    data: [22, 23, 24, 23, 22],
                    borderColor: 'rgb(239, 68, 68)',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)'
                },
                {
                    label: 'Humidity (%)',
                    data: [45, 47, 46, 48, 47],
                    borderColor: 'rgb(59, 130, 246)',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)'
                },
                {
                    label: 'Vibration (mm/s)',
                    data: [1.2, 1.3, 1.1, 1.4, 1.2],
                    borderColor: 'rgb(16, 185, 129)',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)'
                }
            ]
        };

        this.charts.sensorTrends = new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    updateFailurePredictionsChart() {
        const ctx = document.getElementById('failure-predictions-chart');
        if (!ctx) return;

        // Destroy existing chart if it exists
        if (this.charts.failurePredictions) {
            this.charts.failurePredictions.destroy();
        }

        // Sample data
        const data = {
            labels: ['Machine A', 'Machine B', 'Machine C', 'Machine D', 'Machine E'],
            datasets: [{
                label: 'Predicted Failure Time (hours)',
                data: [168, 72, 240, 48, 120],
                backgroundColor: [
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(245, 158, 11, 0.8)',
                    'rgba(59, 130, 246, 0.8)',
                    'rgba(239, 68, 68, 0.8)',
                    'rgba(139, 92, 246, 0.8)'
                ]
            }]
        };

        this.charts.failurePredictions = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Hours'
                        }
                    }
                }
            }
        });
    }

    updatePerformanceMetrics() {
        const container = document.getElementById('performance-metrics');
        if (!container) return;

        // Sample metrics data
        const metrics = {
            anomaly_detection_accuracy: 92.5,
            prediction_accuracy: 87.3,
            false_positive_rate: 5.2,
            system_uptime: 99.8,
            data_quality_score: 94.1
        };

        container.innerHTML = `
            <div class="space-y-4">
                ${Object.entries(metrics).map(([key, value]) => `
                    <div class="flex items-center justify-between">
                        <span class="text-sm font-medium text-gray-700 capitalize">
                            ${key.replace(/_/g, ' ')}
                        </span>
                        <div class="flex items-center space-x-2">
                            <div class="w-32 bg-gray-200 rounded-full h-2">
                                <div class="bg-blue-600 h-2 rounded-full" style="width: ${value}%"></div>
                            </div>
                            <span class="text-sm font-bold text-gray-900">${value}%</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    async acknowledgeAlert(alertId) {
        try {
            await apiClient.acknowledgeAlert(alertId);
            this.showNotification('Alert acknowledged successfully', 'success');
            this.loadCurrentTabData();
        } catch (error) {
            console.error('Error acknowledging alert:', error);
            this.showNotification('Failed to acknowledge alert', 'error');
        }
    }

    async resolveAlert(alertId) {
        try {
            await apiClient.resolveAlert(alertId);
            this.showNotification('Alert resolved successfully', 'success');
            this.loadCurrentTabData();
        } catch (error) {
            console.error('Error resolving alert:', error);
            this.showNotification('Failed to resolve alert', 'error');
        }
    }

    filterAlerts(severity) {
        // This would filter the alerts table based on severity
        // Implementation depends on how alerts are stored and displayed
        console.log('Filtering alerts by severity:', severity);
        this.loadAlerts(); // Reload with filter
    }

    startAutoRefresh() {
        // Refresh data every 30 seconds
        this.refreshInterval = setInterval(() => {
            this.loadCurrentTabData();
        }, 30000);
    }

    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }

    updateConnectionStatus(connected) {
        const statusElement = document.getElementById('connection-status');
        const textElement = document.getElementById('connection-text');
        
        if (connected) {
            statusElement.className = 'w-3 h-3 rounded-full bg-green-500 pulse-glow';
            textElement.textContent = 'Connected';
            textElement.className = 'text-sm text-green-600';
        } else {
            statusElement.className = 'w-3 h-3 rounded-full bg-red-500';
            textElement.textContent = 'Disconnected';
            textElement.className = 'text-sm text-red-600';
        }
    }

    showLoading(show) {
        const loadingElement = document.getElementById('loading-indicator');
        if (loadingElement) {
            loadingElement.style.display = show ? 'flex' : 'none';
        }
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
            type === 'success' ? 'bg-green-500 text-white' :
            type === 'error' ? 'bg-red-500 text-white' :
            'bg-blue-500 text-white'
        }`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    // Utility methods
    getSeverityColor(severity) {
        const colors = {
            critical: 'red',
            high: 'orange',
            medium: 'yellow',
            low: 'green'
        };
        return colors[severity] || 'gray';
    }

    getSensorIcon(sensorType) {
        const icons = {
            temperature: 'thermometer-half',
            humidity: 'tint',
            noise: 'volume-up',
            tension: 'bolt',
            vibration: 'wave-square'
        };
        return icons[sensorType] || 'circle';
    }

    getStatusClass(status) {
        const classes = {
            active: 'bg-green-100 text-green-800',
            inactive: 'bg-red-100 text-red-800',
            maintenance: 'bg-yellow-100 text-yellow-800',
            fault: 'bg-red-100 text-red-800'
        };
        return classes[status] || 'bg-gray-100 text-gray-800';
    }

    formatTimestamp(timestamp) {
        if (!timestamp) return 'Unknown';
        
        const date = new Date(timestamp);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMins / 60);
        const diffDays = Math.floor(diffHours / 24);

        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffHours < 24) return `${diffHours}h ago`;
        if (diffDays < 7) return `${diffDays}d ago`;
        
        return date.toLocaleDateString();
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new MaintAIDashboard();
});

// Handle page visibility changes to pause/resume auto-refresh
document.addEventListener('visibilitychange', () => {
    if (window.dashboard) {
        if (document.hidden) {
            window.dashboard.stopAutoRefresh();
        } else {
            window.dashboard.startAutoRefresh();
        }
    }
});

