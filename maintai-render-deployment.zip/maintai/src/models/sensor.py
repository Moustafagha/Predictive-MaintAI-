from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class SensorData(db.Model):
    __tablename__ = 'sensor_data'
    
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(100), nullable=False, index=True)
    sensor_type = db.Column(db.String(50), nullable=False)  # temperature, humidity, noise, tension, vibration
    value = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(20), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    location = db.Column(db.String(200))
    factory_id = db.Column(db.String(100), nullable=False, index=True)
    machine_id = db.Column(db.String(100), nullable=False, index=True)
    
    # Additional metadata for Algerian industrial context
    shift = db.Column(db.String(20))  # morning, afternoon, night
    operator_id = db.Column(db.String(50))
    production_line = db.Column(db.String(100))
    
    def __repr__(self):
        return f'<SensorData {self.device_id}:{self.sensor_type}={self.value}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'device_id': self.device_id,
            'sensor_type': self.sensor_type,
            'value': self.value,
            'unit': self.unit,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'location': self.location,
            'factory_id': self.factory_id,
            'machine_id': self.machine_id,
            'shift': self.shift,
            'operator_id': self.operator_id,
            'production_line': self.production_line
        }

class Alert(db.Model):
    __tablename__ = 'alerts'
    
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(100), nullable=False, index=True)
    sensor_type = db.Column(db.String(50), nullable=False)
    alert_type = db.Column(db.String(50), nullable=False)  # anomaly, prediction, threshold
    severity = db.Column(db.String(20), nullable=False)  # low, medium, high, critical
    message = db.Column(db.Text, nullable=False)
    message_ar = db.Column(db.Text)  # Arabic message for Algerian market
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    acknowledged = db.Column(db.Boolean, default=False)
    acknowledged_by = db.Column(db.String(100))
    acknowledged_at = db.Column(db.DateTime)
    resolved = db.Column(db.Boolean, default=False)
    resolved_by = db.Column(db.String(100))
    resolved_at = db.Column(db.DateTime)
    
    # Prediction details
    predicted_failure_time = db.Column(db.DateTime)
    confidence_score = db.Column(db.Float)
    
    # Factory context
    factory_id = db.Column(db.String(100), nullable=False, index=True)
    machine_id = db.Column(db.String(100), nullable=False, index=True)
    production_line = db.Column(db.String(100))
    
    def __repr__(self):
        return f'<Alert {self.device_id}:{self.alert_type}:{self.severity}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'device_id': self.device_id,
            'sensor_type': self.sensor_type,
            'alert_type': self.alert_type,
            'severity': self.severity,
            'message': self.message,
            'message_ar': self.message_ar,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'acknowledged': self.acknowledged,
            'acknowledged_by': self.acknowledged_by,
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            'resolved': self.resolved,
            'resolved_by': self.resolved_by,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'predicted_failure_time': self.predicted_failure_time.isoformat() if self.predicted_failure_time else None,
            'confidence_score': self.confidence_score,
            'factory_id': self.factory_id,
            'machine_id': self.machine_id,
            'production_line': self.production_line
        }

class MaintenanceRecord(db.Model):
    __tablename__ = 'maintenance_records'
    
    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.String(100), nullable=False, index=True)
    factory_id = db.Column(db.String(100), nullable=False, index=True)
    maintenance_type = db.Column(db.String(50), nullable=False)  # preventive, corrective, emergency
    description = db.Column(db.Text, nullable=False)
    description_ar = db.Column(db.Text)  # Arabic description
    technician_id = db.Column(db.String(100), nullable=False)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='in_progress')  # scheduled, in_progress, completed, cancelled
    cost = db.Column(db.Float)
    parts_used = db.Column(db.Text)  # JSON string of parts
    notes = db.Column(db.Text)
    
    # Related alert if maintenance was triggered by prediction
    alert_id = db.Column(db.Integer, db.ForeignKey('alerts.id'))
    
    def __repr__(self):
        return f'<MaintenanceRecord {self.machine_id}:{self.maintenance_type}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'machine_id': self.machine_id,
            'factory_id': self.factory_id,
            'maintenance_type': self.maintenance_type,
            'description': self.description,
            'description_ar': self.description_ar,
            'technician_id': self.technician_id,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'status': self.status,
            'cost': self.cost,
            'parts_used': json.loads(self.parts_used) if self.parts_used else [],
            'notes': self.notes,
            'alert_id': self.alert_id
        }

class Factory(db.Model):
    __tablename__ = 'factories'
    
    id = db.Column(db.String(100), primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    name_ar = db.Column(db.String(200))  # Arabic name
    location = db.Column(db.String(200), nullable=False)
    wilaya = db.Column(db.String(100))  # Algerian province
    industry_type = db.Column(db.String(100), nullable=False)
    contact_email = db.Column(db.String(120))
    contact_phone = db.Column(db.String(20))
    manager_name = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Siemens/Schneider integration settings
    plc_type = db.Column(db.String(50))  # siemens_s7, schneider_modicon, etc.
    plc_ip = db.Column(db.String(15))
    plc_port = db.Column(db.Integer)
    tia_portal_version = db.Column(db.String(20))
    
    def __repr__(self):
        return f'<Factory {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'name_ar': self.name_ar,
            'location': self.location,
            'wilaya': self.wilaya,
            'industry_type': self.industry_type,
            'contact_email': self.contact_email,
            'contact_phone': self.contact_phone,
            'manager_name': self.manager_name,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'plc_type': self.plc_type,
            'plc_ip': self.plc_ip,
            'plc_port': self.plc_port,
            'tia_portal_version': self.tia_portal_version
        }

class Machine(db.Model):
    __tablename__ = 'machines'
    
    id = db.Column(db.String(100), primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    name_ar = db.Column(db.String(200))  # Arabic name
    factory_id = db.Column(db.String(100), db.ForeignKey('factories.id'), nullable=False)
    machine_type = db.Column(db.String(100), nullable=False)
    manufacturer = db.Column(db.String(100))
    model = db.Column(db.String(100))
    installation_date = db.Column(db.Date)
    last_maintenance = db.Column(db.DateTime)
    next_scheduled_maintenance = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='operational')  # operational, maintenance, fault, offline
    production_line = db.Column(db.String(100))
    
    # Sensor configuration
    sensors_config = db.Column(db.Text)  # JSON string of sensor configurations
    
    def __repr__(self):
        return f'<Machine {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'name_ar': self.name_ar,
            'factory_id': self.factory_id,
            'machine_type': self.machine_type,
            'manufacturer': self.manufacturer,
            'model': self.model,
            'installation_date': self.installation_date.isoformat() if self.installation_date else None,
            'last_maintenance': self.last_maintenance.isoformat() if self.last_maintenance else None,
            'next_scheduled_maintenance': self.next_scheduled_maintenance.isoformat() if self.next_scheduled_maintenance else None,
            'status': self.status,
            'production_line': self.production_line,
            'sensors_config': json.loads(self.sensors_config) if self.sensors_config else {}
        }

