from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(200), nullable=False)
    full_name_ar = db.Column(db.String(200))  # Arabic name for Algerian users
    phone = db.Column(db.String(20))
    role = db.Column(db.String(50), nullable=False, default='operator')  # admin, manager, technician, operator
    factory_id = db.Column(db.String(100))
    department = db.Column(db.String(100))
    shift = db.Column(db.String(20))  # morning, afternoon, night
    language = db.Column(db.String(10), default='en')  # en, ar, fr
    timezone = db.Column(db.String(50), default='Africa/Algiers')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    
    # Notification preferences
    sms_notifications = db.Column(db.Boolean, default=True)
    email_notifications = db.Column(db.Boolean, default=True)
    push_notifications = db.Column(db.Boolean, default=True)
    notification_severity_threshold = db.Column(db.String(20), default='medium')  # low, medium, high, critical

    def __repr__(self):
        return f'<User {self.username}>'
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'full_name_ar': self.full_name_ar,
            'phone': self.phone,
            'role': self.role,
            'factory_id': self.factory_id,
            'department': self.department,
            'shift': self.shift,
            'language': self.language,
            'timezone': self.timezone,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'is_active': self.is_active,
            'sms_notifications': self.sms_notifications,
            'email_notifications': self.email_notifications,
            'push_notifications': self.push_notifications,
            'notification_severity_threshold': self.notification_severity_threshold
        }
